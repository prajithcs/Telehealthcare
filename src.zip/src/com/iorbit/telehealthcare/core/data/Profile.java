package com.iorbit.telehealthcare.core.data;

public class Profile {

}
