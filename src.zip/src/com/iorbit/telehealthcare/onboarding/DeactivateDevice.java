package com.iorbit.telehealthcare.onboarding;

public class DeactivateDevice {
	
	public DeactivateDevice()
	   {
		   
	   }

}
