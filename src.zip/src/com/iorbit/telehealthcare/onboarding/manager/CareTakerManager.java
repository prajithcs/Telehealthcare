package com.iorbit.telehealthcare.onboarding.manager;

import com.iorbit.telehealthcare.core.data.*;
import com.iorbit.telehealthcare.onboarding.AddCarehome;
import com.iorbit.telehealthcare.onboarding.AddCaretaker;
import com.iorbit.telehealthcare.onboarding.AddSubscriber;
import com.iorbit.telehealthcare.onboarding.AttachCarehome;
import com.iorbit.telehealthcare.onboarding.AttachSubscriber;
import com.iorbit.telehealthcare.onboarding.DetachCarehome;
import com.iorbit.telehealthcare.onboarding.DetachSubscriber;
import com.iorbit.telehealthcare.onboarding.EmailVerification;

public class CareTakerManager {

	public void addCareTaker(AddCaretaker addCaretaker, CareTaker careTaker) {

	}

	public void validateCaretaker(CareTaker taker) {

	}

	public void addCareHome(AddCarehome addCarehome, CareHome careHome) {

	}

	public void addSubscriber(AddSubscriber addSubscriber, Subscriber subscriber) {

	}

	public void emailVerification(EmailVerification emailVerification) {

	}

	public void attachCarehome(AttachCarehome carehome) {

	}

	public void attachsubscriber(AttachSubscriber attachSubscriber) {

	}

	public void detachSubscriber(DetachSubscriber subscriber) {

	}

	public void detachCarehome(DetachCarehome carehome) {

	}

}
