package com.iorbit.telehealthcare.onboarding;

public class DeviceConnectivityTested {
	 
		 
	 public DeviceConnectivityTested()
	 {
		
	 }
	 

}
