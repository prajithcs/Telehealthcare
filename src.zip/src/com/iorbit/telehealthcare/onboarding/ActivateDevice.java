package com.iorbit.telehealthcare.onboarding;

public class ActivateDevice {
	

	//private int deviceId;
	
}
