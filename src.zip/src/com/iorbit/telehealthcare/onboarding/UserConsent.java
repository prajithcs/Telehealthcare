package com.iorbit.telehealthcare.onboarding;

public class UserConsent {
	
	private String consent1;
	private String consent2;
	public UserConsent()
	{
		
	}
	public String getConsent1() {
		return consent1;
	}
	public void setConsent1(String consent1) {
		this.consent1 = consent1;
	}
	public String getConsent2() {
		return consent2;
	}
	public void setConsent2(String consent2) {
		this.consent2 = consent2;
	}
	
}
