package com.iorbit.telehealthcare.onboarding;

public class ActivateCarehome {
	
	private String name;
	private String subscriberId;
	private String caretakerId;
	
	
	

}
